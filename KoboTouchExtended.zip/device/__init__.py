"""KoboTouchExtended device driver."""
